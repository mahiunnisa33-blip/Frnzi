import 'package:flutter/material.dart';

void main() => runApp(const FrnziApp());

class FrnziApp extends StatelessWidget {
  const FrnziApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'FRNZI',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFFFF8FC),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFE90072),
          brightness: Brightness.light,
        ),
        fontFamily: 'Roboto',
      ),
      home: const WelcomeScreen(),
    );
  }
}

const pink = Color(0xFFE90072);
const purple = Color(0xFF8E24AA);

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              Container(
                width: 92, height: 92,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [pink, purple]),
                  borderRadius: BorderRadius.circular(28),
                ),
                child: const Icon(Icons.forum_rounded, color: Colors.white, size: 50),
              ),
              const SizedBox(height: 20),
              const Text('FRNZI', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900, color: pink)),
              const Text('Meet. Talk. Connect.', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              const Text('Connect with people, learn new languages and make real friends from around the world.',
                  textAlign: TextAlign.center, style: TextStyle(color: Colors.black54, fontSize: 16)),
              const Spacer(),
              _Button(label: 'Get Started', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LanguageScreen()))),
              const SizedBox(height: 12),
              OutlinedButton(
                style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen())),
                child: const Text('I already have an account'),
              ),
              const SizedBox(height: 18),
              const Text('By continuing, you agree to our Terms & Privacy Policy', style: TextStyle(fontSize: 11, color: Colors.black45)),
            ],
          ),
        ),
      ),
    );
  }
}

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({super.key});
  @override State<LanguageScreen> createState() => _LanguageScreenState();
}
class _LanguageScreenState extends State<LanguageScreen> {
  final selected = <String>{'English'};
  final languages = ['English','Hindi','Telugu','Tamil','Malayalam','Kannada','Bengali','Marathi','Punjabi','Gujarati','Urdu'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Select Languages'), backgroundColor: Colors.transparent),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('What languages do you speak?', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 8),
        const Text('Choose the languages you can speak or understand.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 20),
        Expanded(child: GridView.count(crossAxisCount: 2, childAspectRatio: 3.2, crossAxisSpacing: 10, mainAxisSpacing: 10,
          children: languages.map((l) => ChoiceChip(
            label: Text(l), selected: selected.contains(l),
            onSelected: (v) => setState(() => v ? selected.add(l) : selected.remove(l)),
          )).toList())),
        _Button(label: 'Continue', onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InterestsScreen()))),
      ]),
    ),
  );
}

class InterestsScreen extends StatefulWidget {
  const InterestsScreen({super.key});
  @override State<InterestsScreen> createState() => _InterestsScreenState();
}
class _InterestsScreenState extends State<InterestsScreen> {
  final selected = <String>{};
  final interests = ['🎵 Music','🎬 Movies','⚽ Sports','🍳 Cooking','✈️ Travel','🎨 Art','📚 Books','🎮 Gaming','💻 Tech','🏃 Fitness','🌿 Nature','👗 Fashion'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Select Interests'), backgroundColor: Colors.transparent),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('What do you love?', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const Text('Pick at least 3 interests.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 20),
        Expanded(child: GridView.count(crossAxisCount: 3, crossAxisSpacing: 10, mainAxisSpacing: 10,
          children: interests.map((x) {
            final on = selected.contains(x);
            return InkWell(onTap: () => setState(() => on ? selected.remove(x) : selected.add(x)),
              borderRadius: BorderRadius.circular(18),
              child: Container(decoration: BoxDecoration(color: on ? pink.withOpacity(.1) : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: on ? pink : Colors.black12)),
                child: Center(child: Text(x, textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w600, color: on ? pink : Colors.black87)))));
          }).toList())),
        _Button(label: 'Enter FRNZI', onTap: () => Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false)),
      ]),
    ),
  );
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int tab = 0;
  final names = ['Sana_22','Aarav_25','Riya_19','Zara_21','Karan_26','Meena_23'];
  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeBody(context),
      const DiscoverPage(),
      const ChatsPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: SafeArea(child: pages[tab]),
      floatingActionButton: FloatingActionButton(backgroundColor: pink, foregroundColor: Colors.white, onPressed: () => _showNewChat(context), child: const Icon(Icons.add)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.search), label: 'Discover'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }

  Widget _homeBody(BuildContext context) => ListView(padding: const EdgeInsets.fromLTRB(20, 18, 20, 90), children: [
    Row(children: [
      const Expanded(child: Text('FRNZI', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: pink))),
      IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      IconButton(onPressed: () {}, icon: const Icon(Icons.search)),
    ]),
    Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [pink, purple]), borderRadius: BorderRadius.circular(24)),
      child: const Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Break the language barrier', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w800)),
          SizedBox(height: 5), Text('Make new friends', style: TextStyle(color: Colors.white70)),
        ])),
        Icon(Icons.forum_rounded, color: Colors.white, size: 52),
      ]),
    ),
    const SizedBox(height: 24),
    const Text('Online now', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    const SizedBox(height: 12),
    SizedBox(height: 88, child: ListView.separated(scrollDirection: Axis.horizontal, itemCount: 5, separatorBuilder: (_,__) => const SizedBox(width: 18),
      itemBuilder: (_,i) => Column(children: [
        Stack(children: [
          CircleAvatar(radius: 27, backgroundColor: [pink, purple, Colors.orange, Colors.teal, Colors.indigo][i], child: Text(names[i][0], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20))),
          Positioned(right: 0, bottom: 0, child: Container(width: 13, height: 13, decoration: BoxDecoration(color: Colors.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)))),
        ]),
        const SizedBox(height: 4), Text(names[i], style: const TextStyle(fontSize: 12)),
      ]))),
    const SizedBox(height: 16),
    const Text('Suggested for you', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
    ...names.map((n) => Card(margin: const EdgeInsets.only(top: 10), child: ListTile(
      leading: CircleAvatar(backgroundColor: pink.withOpacity(.12), child: Text(n[0], style: const TextStyle(color: pink, fontWeight: FontWeight.bold))),
      title: Text(n, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('Hindi • English  |  Music • Movies'),
      trailing: FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(name: n))), child: const Text('Chat')),
    ))),
  ]);

  void _showNewChat(BuildContext context) {
    showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('Start a new conversation', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
      const SizedBox(height: 14), const Text('Find someone by language or interest.'),
      const SizedBox(height: 14), _Button(label: 'Discover people', onTap: () { Navigator.pop(context); setState(() => tab = 1); }),
    ])));
  }
}

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Discover', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), const Text('Find people who share your languages and interests.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search people...', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
    const SizedBox(height: 20),
    ...['Sana_22','Aarav_25','Riya_19','Zara_21'].map((n) => Card(child: ListTile(
      leading: CircleAvatar(backgroundColor: pink, child: Text(n[0], style: const TextStyle(color: Colors.white))),
      title: Text(n, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: const Text('English • Hindi • Music • Travel'),
      trailing: IconButton(icon: const Icon(Icons.chat, color: pink), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(name: n)))),
    ))),
  ]);
}

class ChatsPage extends StatelessWidget {
  const ChatsPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Chats', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 14),
    TextField(decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: 'Search chats...', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
    const SizedBox(height: 14),
    ...['Sana_22','Aarav_25','Riya_19','Zara_21','Karan_26'].map((n) => ListTile(
      contentPadding: const EdgeInsets.symmetric(vertical: 5),
      leading: CircleAvatar(backgroundColor: purple, child: Text(n[0], style: const TextStyle(color: Colors.white))),
      title: Text(n, style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: const Text('Hey! How are you? 😊'),
      trailing: const Text('8:45 PM', style: TextStyle(fontSize: 11, color: Colors.black45)),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatPage(name: n))),
    )),
  ]);
}

class ChatPage extends StatefulWidget {
  final String name;
  const ChatPage({super.key, required this.name});
  @override State<ChatPage> createState() => _ChatPageState();
}
class _ChatPageState extends State<ChatPage> {
  final controller = TextEditingController();
  final messages = <String>['Hi! I’m ${'Sana'}, which languages do you speak?', 'I speak Hindi and English. And you?'];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Row(children: [CircleAvatar(backgroundColor: pink, radius: 17, child: Text(widget.name[0], style: const TextStyle(color: Colors.white))), const SizedBox(width: 10), Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(widget.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)), const Text('Online', style: TextStyle(fontSize: 11, color: Colors.green))])]), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.call))]),
    body: Column(children: [
      Expanded(child: ListView(padding: const EdgeInsets.all(16), children: [
        ...messages.asMap().entries.map((e) => Align(alignment: e.key.isEven ? Alignment.centerLeft : Alignment.centerRight, child: Container(
          margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(color: e.key.isEven ? Colors.white : pink, borderRadius: BorderRadius.circular(18)),
          child: Text(e.value, style: TextStyle(color: e.key.isEven ? Colors.black87 : Colors.white)),
        ))),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Row(children: [Icon(Icons.translate, color: pink), SizedBox(width: 8), Text('Auto Translate  EN → HI', style: TextStyle(fontWeight: FontWeight.w600)), Spacer(), Icon(Icons.copy, size: 18)])),
      ])),
      SafeArea(child: Padding(padding: const EdgeInsets.all(10), child: Row(children: [
        IconButton(onPressed: () {}, icon: const Icon(Icons.attach_file)),
        Expanded(child: TextField(controller: controller, decoration: InputDecoration(hintText: 'Type a message...', filled: true, fillColor: Colors.white, border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: BorderSide.none)))),
        IconButton(onPressed: () { if (controller.text.trim().isNotEmpty) { setState(() { messages.add(controller.text.trim()); controller.clear(); }); } }, icon: const Icon(Icons.send, color: pink)),
      ]))),
    ]),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Profile', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
    const SizedBox(height: 25),
    const Center(child: CircleAvatar(radius: 50, backgroundColor: pink, child: Text('M', style: TextStyle(color: Colors.white, fontSize: 38, fontWeight: FontWeight.bold)))),
    const SizedBox(height: 12),
    const Center(child: Text('Your FRNZI Profile', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800))),
    const Center(child: Text('Hindi • English', style: TextStyle(color: Colors.black54))),
    const SizedBox(height: 25),
    ...[
      ['❤️','My Languages'],['✨','My Interests'],['🔒','Privacy & Security'],['🔔','Notifications'],['❓','Help & Support'],['ℹ️','About FRNZI']
    ].map((x) => Card(child: ListTile(leading: Text(x[0], style: const TextStyle(fontSize: 22)), title: Text(x[1], style: const TextStyle(fontWeight: FontWeight.w600)), trailing: const Icon(Icons.chevron_right)))),
    const SizedBox(height: 12),
    OutlinedButton(onPressed: () {}, style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(52)), child: const Text('Log Out')),
  ]);
}

class _Button extends StatelessWidget {
  final String label; final VoidCallback onTap;
  const _Button({required this.label, required this.onTap});
  @override Widget build(BuildContext context) => SizedBox(width: double.infinity, height: 54, child: FilledButton(
    style: FilledButton.styleFrom(backgroundColor: pink, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
    onPressed: onTap, child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
  ));
}
